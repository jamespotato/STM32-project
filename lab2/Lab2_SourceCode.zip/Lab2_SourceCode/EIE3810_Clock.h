#ifndef __EIE3810_CLOCK_H
#define __EIE3810_CLOCK_H
#include "stm32f10x.h"

void EIE3810_clock_tree_init(void);

#endif