#ifndef __EIE3810_KEY_H
#define __EIE3810_KEY_H
#include "stm32f10x.h"


void EIE3810_Key_Init(void);

uint16_t readKey1(void);

uint16_t readKey2(void);

uint16_t readKey_up(void);

#endif
