#ifndef __EIE3810_LED_H
#define __EIE3810_LED_H
#include "stm32f10x.h"

#define DS0_ON TurnOnLED0()
#define DS0_OFF TurnOffLED0()
#define DS1_ON TurnOnLED1()
#define DS1_OFF TurnOffLED1()

void EIE3810_LED_Init(void);

void TurnOnLED0(void);

void TurnOnLED1(void);

void TurnOffLED1(void);

void ToggleLED1(void);

void TurnOffLED0(void);



#endif
