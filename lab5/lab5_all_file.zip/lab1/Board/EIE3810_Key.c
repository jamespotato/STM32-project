 #include "stm32f10x.h"
#include "EIE3810_Key.h"

//this function is used to initialize key1 and key2 as well as key_up

void EIE3810_Key_Init(void)
{
	//Key2 PE2
	RCC->APB2ENR|=1<<6;		//Enable GPIOE
	GPIOE->CRL &=0xFFFFF0FF;//Clear the bit of the PE2
	GPIOE->CRL |=0x00000800;//Set PE2 as input pull-up/pull-down mode
	GPIOE->ODR |= 1<<2;		//Set input mode pull-up

	//Key1 PE3
	RCC->APB2ENR|=1<<6;		//Enable GPIOE
	GPIOE->CRL &=0xFFFF0FFF;//Clear the bit of the PE3
	GPIOE->CRL |=0x00008000;//Set PE3 as input pull-up/pull-down mode
	GPIOE->ODR |= 1<<3;		//Set input mode pull-up

	//Key_up PA0
	RCC->APB2ENR|=1<<2;		//Enable GPIOA
	GPIOA->CRL &=0xFFFFFFF0;//Clear the bit of the PA0
	GPIOA->CRL |=0x00000008;//Set PE3 as input pull-up/pull-down mode
							//it is pull-down by default
}	


uint16_t readKey1(void)		//this function will return the specified bit stand for Key1
{							//If key1 is pressed, it would be 0x0000
	return GPIOE->IDR & 0x0008;//Read from the IDR and do masking with "&" 
}

uint16_t readKey2(void)		//this function will return the specified bit stand for Key2
{							//If key2 is pressed, it would be 0x0000
	return GPIOE->IDR & 0x0004;//Read from the IDR and do masking with "&"
}

uint16_t readKey_up(void)	//this function will return the specified bit stand for Key_up
{							//If keyup is pressed, it would be 0x0001
	return GPIOA->IDR & 0x0001;//Read from the IDR and do masking with "&"
}