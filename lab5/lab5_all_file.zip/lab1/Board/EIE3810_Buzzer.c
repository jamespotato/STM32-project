#include "stm32f10x.h"
#include "EIE3810_Buzzer.h"

//This function is used to initialize the buzzer
void EIE3810_Buzzer_Init(void){
	RCC->APB2ENR|=1<<3; 		//Enable GPIOB pin8
	GPIOB->CRH &=0xFFFFFFF0;	//Clear the bit for the PB8
	GPIOB->CRH |=0x00000003; 	//output push-pull mode, max speed 50MHz
}

//This funtion is used to toggle buzzer by checking bit-8 in GPIOB_ODR
//and turn it into the opposite with reset and set register
void toggleBuzzer(void)
{
	if ((GPIOB-> ODR & 0x0100) == 0x0100)	//if bit-8 is high(sound), then we make it not sound
	{
		GPIOB->BRR = 1<<8;					//reset the bit-8 to low(not sound)
	}										//by setting the register BRR to 0x0100
	else 
	{
		GPIOB->BSRR = 1<<8;				//otherwise, set bit-8 to high(sound)
	}									//by setting the register BSRR to 0x0100
}