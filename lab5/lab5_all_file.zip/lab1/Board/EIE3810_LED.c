#include "stm32f10x.h"
#include "EIE3810_LED.h"

//This function will initialize LED0 and LED1 to output push-pull mode
//with maximum speed up to 50MHz

void EIE3810_LED_Init(void){
	//LED0 PB5
	RCC->APB2ENR|=1<<3; 		//Enable GPIOB
	GPIOB->CRL &=0xFF0FFFFF;	//Clear the bit for the PB5
	GPIOB->CRL |=0x00300000; 	//Set PB5 as output push-pull mode, max speed 50MHz
	
	//LED1 PE5
	RCC->APB2ENR|=1<<6; 		//Enable GPIOE
	GPIOE->CRL &=0xFF0FFFFF;	//Clear the bit for the PE5
	GPIOE->CRL |=0x00300000; 	//Set PE5 as output push-pull mode, max speed 50MHz
}


void TurnOnLED1(void)	//This function will turn on LED0 by setting the BRR to 0x0020
{
	GPIOE->BRR = 1<<5; 
}

void TurnOffLED1(void)	//This function will turn off LED0 by setting the BSRR to 0x0020
{
	GPIOE->BSRR = 1<<5; 
}


void TurnOnLED0(void)
{
	GPIOB->BRR = 1<<5;
}

void TurnOffLED0(void)
{
	GPIOB->BSRR = 1<<5;
}

//This function will turn toggle LED1 by checking bit-5 in GPIOE_ODR
//and change it to the opposite with reset and set register
void ToggleLED1(void)	
{
	if ((GPIOE-> ODR & 0x0020) == 0x0020)	//if bit-5 is high(not lit)
	{
		GPIOE->BRR = 1<<5;					//reset the bit to low(lit)
	}
	else 
	{
		GPIOE->BSRR = 1<<5;				//otherwise, set it to high (not lit)
	}
}